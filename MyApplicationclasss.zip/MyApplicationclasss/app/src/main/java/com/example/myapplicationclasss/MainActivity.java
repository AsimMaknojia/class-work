package com.example.myapplicationclasss;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.RadioGroup;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    TextView tv;
    EditText username;
    EditText emailaddress;
    EditText password;
    EditText phonenumber;
    CheckBox cb;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        tv = findViewById(R.id.textView);
        username = findViewById(R.id.editText);
        password = findViewById(R.id.editText2);
        emailaddress = findViewById(R.id.editText3);
        phonenumber = findViewById(R.id.editText4);
        cb = findViewById(R.id.checkBox);
        cb.setOnClickListener(new View.OnClickListener(){
                public void onClick(View v){
                    if(cb.isChecked())
                        cb.setTextColor(Color.BLACK);

        }
        });
    }

    public void onClickSubmitButton(View v){
//
        String name = username.getText().toString();
        String pass = password.getText(). toString();
        String email = emailaddress.getText(). toString();
        String phone = phonenumber.getText(). toString();
        boolean error = false;
        if(name != null && name.equalsIgnoreCase(""))
        {
            username.setError("Enter Valid Name");
            error =true;
        }
        if(pass != null && pass.equalsIgnoreCase(""))
        {
            password.setError("Enter Valid Name");
            error =true;
        }
        if(email != null && email.equalsIgnoreCase(""))
        {
            emailaddress.setError("Enter Valid Name");
            error =true;
        }
        if(phone != null && phone.equalsIgnoreCase(""))
        {
            phonenumber.setError("Enter Valid Name");
            error =true;
        }
        if(!cb.isChecked()){
            cb.setTextColor(Color.RED);
            error = true;
        }

        if(!error){
            Intent intend = new Intent(this, Main2Activity.class);
            startActivity(intend);
        }



        }
    }

